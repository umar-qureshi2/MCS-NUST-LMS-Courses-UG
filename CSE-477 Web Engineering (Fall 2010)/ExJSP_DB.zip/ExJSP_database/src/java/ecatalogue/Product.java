package ecatalogue;

/**
 * @author Dr. Awais Majeed
 */
public class Product {
    
    private long itemID;
    private String itemName;
    private String itemDesc;
    private float price;
    private long quantity;
    
    public void Product(){
        
    }
    
    public void setitemID(long id){
        itemID=id;        
    }
    
    public void setitemName(String name){
        itemName=name;
    }
    
    public void setitemDesc(String desc){
        itemDesc=desc;
    }
    
    public void setprice(float myprice){
        price=myprice;
    }
    
    public void setquantity(long newquantity){
        quantity=newquantity;
    }

    //
    public long getitemID(){
        return itemID;
    }
    
    public String getitemName(){
        return itemName;
    }
    
    public String getitemDesc(){
        return itemDesc;
    }
    
    public float getprice(){
        return price;
    }
    
    public long setquantity(){
        return quantity;
    }
            
}
