/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ecatalogue;
import java.sql.*;



/**
 *
 * @author Awais
 */
public class CatalogueDB {

    private String DBUrl;
    private String catDB;
    private Connection con=null;
    private Statement st; 
    private ResultSet rs; 
    private String sql;     
    
    public int initCatalogue(){
        
        DBUrl="F:\\MCS\\Teaching\\UG\\WebEngineering\\Labs\\ExJSP_DB\\eCatalogue.mdb";
        catDB="jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};DBQ=" + DBUrl + ";DriverID=22";
        try {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); //loads the driver            
            con=DriverManager.getConnection(catDB);
            st=con.createStatement();
        }
        catch (Exception e){
            return 0;
        }
        return 1;
        
    }
    
    public void insertItem(String[] fields) throws SQLException{
        
        sql="insert into Catalogue (ItemName, ItemDescription, Price, Quantity) Values (";
        sql=sql + "'" + fields[0] + "',";
        sql=sql + "'" + fields[1] + "',";
        sql=sql + fields[2].toString() + "," + fields[3].toString() + ")";
        st.execute(sql);
        st.close();
        con.close();
        
    }// end of function
    
    public ResultSet getCatalogue() throws SQLException{
        sql="select * from Catalogue";
        st.execute(sql);
        rs=st.getResultSet();      
        return rs;
    }
    
    public void closecon() throws SQLException{
        st.close();
        con.close();
    }
    //Gap 1
    public ResultSet getProduct(String productname) throws SQLException{
        //<<Gap 1>>
        //implement the functionality of a search where a user can enter a product
        //name to retrive the relevant products from the database
        return (rs);
    }
    
    
} //end of class
